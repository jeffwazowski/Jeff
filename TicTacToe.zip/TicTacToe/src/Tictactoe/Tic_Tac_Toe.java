/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tictactoe;

import java.awt.Color;
import javax.swing.*;
import javax.swing.*;

/**
 *
 * @author Jefry
 */
public class Tic_Tac_Toe extends javax.swing.JFrame {

    private JFrame frame;
    private String startGame ="X";
    private int xCount = 0;
    private int oCount = 0;
    private String reset ="";
    private String btn1 = "";
    private String btn2 = "";
    private String btn3 = "";
    private String btn4 = "";
    private String btn5 = "";
    private String btn6 = "";
    private String btn7 = "";
    private String btn8 = "";
    private String btn9 = "";
    
    
    /**
     * Creates new form Tic_Tac_Toe
     */
    public Tic_Tac_Toe() {
        initComponents();
        start();
        setLocationRelativeTo(null);
        choose_a_player();
    }
    
    private void start(){
        jLabel_btn_o1.setVisible(false);
        jLabel_btn_o2.setVisible(false);
        jLabel_btn_o3.setVisible(false);
        jLabel_btn_o4.setVisible(false);
        jLabel_btn_o5.setVisible(false);
        jLabel_btn_o6.setVisible(false);
        jLabel_btn_o7.setVisible(false);
        jLabel_btn_o8.setVisible(false);
        jLabel_btn_o9.setVisible(false);
        jLabel_btn_x1.setVisible(false);
        jLabel_btn_x2.setVisible(false);
        jLabel_btn_x3.setVisible(false);
        jLabel_btn_x4.setVisible(false);
        jLabel_btn_x5.setVisible(false);
        jLabel_btn_x6.setVisible(false);
        jLabel_btn_x7.setVisible(false);
        jLabel_btn_x8.setVisible(false);
        jLabel_btn_x9.setVisible(false);
        jLabel_btn_o_win1.setVisible(false);
        jLabel_btn_o_win2.setVisible(false);
        jLabel_btn_o_win3.setVisible(false);
        jLabel_btn_o_win4.setVisible(false);
        jLabel_btn_o_win5.setVisible(false);
        jLabel_btn_o_win6.setVisible(false);
        jLabel_btn_o_win7.setVisible(false);
        jLabel_btn_o_win8.setVisible(false);
        jLabel_btn_o_win9.setVisible(false);
        jLabel_btn_x_win1.setVisible(false);
        jLabel_btn_x_win2.setVisible(false);
        jLabel_btn_x_win3.setVisible(false);
        jLabel_btn_x_win4.setVisible(false);
        jLabel_btn_x_win5.setVisible(false);
        jLabel_btn_x_win6.setVisible(false);
        jLabel_btn_x_win7.setVisible(false);
        jLabel_btn_x_win8.setVisible(false);
        jLabel_btn_x_win9.setVisible(false);
    }

    private void gameScore(){
        score_x.setText(String.valueOf(xCount));
        score_o.setText(String.valueOf(oCount));
        reset="reset";
    }
    
    private void check(String btn){
        if(reset=="reset"){
            askreset();
        }else{
            if(btn!=""){
                JOptionPane.showMessageDialog(this, "Is not valid. Try again or Click Reset...","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
    
    private void askreset(){
        if(reset=="reset"){
            frame = new JFrame("Reset");
            if(JOptionPane.showConfirmDialog(frame, "Do You Want Reset The Game?", "Tic Tac Toe",JOptionPane.YES_NO_OPTION )== JOptionPane.YES_NO_OPTION)
            {
                reset();
            }
        }
    }
    
    private void reset(){
        if(reset=="reset"){
                start();
                reset="";
                btn1 = "";
                btn2 = "";
                btn3 = "";
                btn4 = "";
                btn5 = "";
                btn6 = "";
                btn7 = "";
                btn8 = "";
                btn9 = "";
            }
    }
    
    
    private void choose_a_player(){
        if(reset=="reset"){
            frame = new JFrame("Reset");
            if(JOptionPane.showConfirmDialog(frame, "Do You Want Reset The Game?", "Tic Tac Toe",JOptionPane.YES_NO_OPTION )== JOptionPane.YES_NO_OPTION)
            {
                start();
            }
        }else{
            if(startGame.equalsIgnoreCase("O")){
                startGame ="X";
                jLabel_lamp.setVisible(false);
                jLabel_lamp1.setVisible(true);
            }else{
                startGame ="O";
                jLabel_lamp.setVisible(true);
                jLabel_lamp1.setVisible(false);
            }
        }
    }
    
    private void winningGame(){
        if (btn1 ==("X") && btn2 ==("X") && btn3 ==("X")) {
            JOptionPane.showMessageDialog(this, "Player 'X' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jLabel_btn_x_win1.setVisible(true);
            jLabel_btn_x_win2.setVisible(true);
            jLabel_btn_x_win3.setVisible(true);
        }
        else if (btn4 ==("X") && btn5 ==("X") && btn6 ==("X")) {
            JOptionPane.showMessageDialog(this, "Player 'X' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jLabel_btn_x_win4.setVisible(true);
            jLabel_btn_x_win5.setVisible(true);
            jLabel_btn_x_win6.setVisible(true);
        }
        else if (btn7 ==("X") && btn8 ==("X") && btn9 ==("X")) {
            JOptionPane.showMessageDialog(this, "Player 'X' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jLabel_btn_x_win7.setVisible(true);
            jLabel_btn_x_win8.setVisible(true);
            jLabel_btn_x_win9.setVisible(true);
        }
        else if (btn1 ==("X") && btn4 ==("X") && btn7 ==("X")) {
            JOptionPane.showMessageDialog(this, "Player 'X' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jLabel_btn_x_win1.setVisible(true);
            jLabel_btn_x_win4.setVisible(true);
            jLabel_btn_x_win7.setVisible(true);
        }
        else if (btn2 ==("X") && btn5 ==("X") && btn8 ==("X")) {
            JOptionPane.showMessageDialog(this, "Player 'X' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jLabel_btn_x_win2.setVisible(true);
            jLabel_btn_x_win5.setVisible(true);
            jLabel_btn_x_win8.setVisible(true);
        }
        else if (btn3 ==("X") && btn6 ==("X") && btn9 ==("X")) {
            JOptionPane.showMessageDialog(this, "Player 'X' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jLabel_btn_x_win3.setVisible(true);
            jLabel_btn_x_win6.setVisible(true);
            jLabel_btn_x_win9.setVisible(true);
        }
        else if (btn1 ==("X") && btn5 ==("X") && btn9 ==("X")) {
            JOptionPane.showMessageDialog(this, "Player 'X' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jLabel_btn_x_win1.setVisible(true);
            jLabel_btn_x_win5.setVisible(true);
            jLabel_btn_x_win9.setVisible(true);
        }
        else if (btn3 ==("X") && btn5 ==("X") && btn7 ==("X")) {
            JOptionPane.showMessageDialog(this, "Player 'X' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            xCount++;
            gameScore();
            jLabel_btn_x_win3.setVisible(true);
            jLabel_btn_x_win5.setVisible(true);
            jLabel_btn_x_win7.setVisible(true);
        }
        
        else if (btn1 ==("O") && btn2 ==("O") && btn3 ==("O")) {
            JOptionPane.showMessageDialog(this, "Player 'O' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jLabel_btn_o_win1.setVisible(true);
            jLabel_btn_o_win2.setVisible(true);
            jLabel_btn_o_win3.setVisible(true);
        }
        else if (btn4 ==("O") && btn5 ==("O") && btn6 ==("O")) {
            JOptionPane.showMessageDialog(this, "Player 'O' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jLabel_btn_o_win4.setVisible(true);
            jLabel_btn_o_win5.setVisible(true);
            jLabel_btn_o_win6.setVisible(true);
        }
        else if (btn7 ==("O") && btn8 ==("O") && btn9 ==("O")) {
            JOptionPane.showMessageDialog(this, "Player 'O' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jLabel_btn_o_win7.setVisible(true);
            jLabel_btn_o_win8.setVisible(true);
            jLabel_btn_o_win9.setVisible(true);
        }
        else if (btn1 ==("O") && btn4 ==("O") && btn7 ==("O")) {
            JOptionPane.showMessageDialog(this, "Player O wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jLabel_btn_o_win1.setVisible(true);
            jLabel_btn_o_win4.setVisible(true);
            jLabel_btn_o_win7.setVisible(true);
        }
        else if (btn2 ==("O") && btn5 ==("O") && btn8 ==("O")) {
            JOptionPane.showMessageDialog(this, "Player 'O' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jLabel_btn_o_win2.setVisible(true);
            jLabel_btn_o_win5.setVisible(true);
            jLabel_btn_o_win8.setVisible(true);
        }
        else if (btn3 ==("O") && btn6 ==("O") && btn9 ==("O")) {
            JOptionPane.showMessageDialog(this, "Player 'O' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jLabel_btn_o_win3.setVisible(true);
            jLabel_btn_o_win6.setVisible(true);
            jLabel_btn_o_win9.setVisible(true);
        }
        else if (btn1 ==("O") && btn5 ==("O") && btn9 ==("O")) {
            JOptionPane.showMessageDialog(this, "Player 'O' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jLabel_btn_o_win1.setVisible(true);
            jLabel_btn_o_win5.setVisible(true);
            jLabel_btn_o_win9.setVisible(true);
        }
        else if (btn3 ==("O") && btn5 ==("O") && btn7 ==("O")) {
            JOptionPane.showMessageDialog(this, "Player 'O' wins","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            oCount++;
            gameScore();
            jLabel_btn_o_win3.setVisible(true);
            jLabel_btn_o_win5.setVisible(true);
            jLabel_btn_o_win7.setVisible(true);
        }
        else if (btn1!=("") && btn2!=("") && btn3!=("") && btn4!=("") && btn5!=("") && btn6!=("") && btn7!=("") && btn8!=("") && btn9!=("")) {
            JOptionPane.showMessageDialog(this, "It's a Draw!","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            reset="reset";
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel_btn_x_win1 = new javax.swing.JLabel();
        jLabel_btn_x_win2 = new javax.swing.JLabel();
        jLabel_btn_x_win3 = new javax.swing.JLabel();
        jLabel_btn_x_win4 = new javax.swing.JLabel();
        jLabel_btn_x_win5 = new javax.swing.JLabel();
        jLabel_btn_x_win6 = new javax.swing.JLabel();
        jLabel_btn_x_win7 = new javax.swing.JLabel();
        jLabel_btn_x_win8 = new javax.swing.JLabel();
        jLabel_btn_x_win9 = new javax.swing.JLabel();
        jLabel_btn_o_win1 = new javax.swing.JLabel();
        jLabel_btn_o_win2 = new javax.swing.JLabel();
        jLabel_btn_o_win3 = new javax.swing.JLabel();
        jLabel_btn_o_win4 = new javax.swing.JLabel();
        jLabel_btn_o_win5 = new javax.swing.JLabel();
        jLabel_btn_o_win6 = new javax.swing.JLabel();
        jLabel_btn_o_win7 = new javax.swing.JLabel();
        jLabel_btn_o_win8 = new javax.swing.JLabel();
        jLabel_btn_o_win9 = new javax.swing.JLabel();
        jLabel_btn_x1 = new javax.swing.JLabel();
        jLabel_btn_x2 = new javax.swing.JLabel();
        jLabel_btn_x3 = new javax.swing.JLabel();
        jLabel_btn_x4 = new javax.swing.JLabel();
        jLabel_btn_x5 = new javax.swing.JLabel();
        jLabel_btn_x6 = new javax.swing.JLabel();
        jLabel_btn_x7 = new javax.swing.JLabel();
        jLabel_btn_x8 = new javax.swing.JLabel();
        jLabel_btn_x9 = new javax.swing.JLabel();
        jLabel_btn_o1 = new javax.swing.JLabel();
        jLabel_btn_o2 = new javax.swing.JLabel();
        jLabel_btn_o3 = new javax.swing.JLabel();
        jLabel_btn_o4 = new javax.swing.JLabel();
        jLabel_btn_o5 = new javax.swing.JLabel();
        jLabel_btn_o6 = new javax.swing.JLabel();
        jLabel_btn_o7 = new javax.swing.JLabel();
        jLabel_btn_o8 = new javax.swing.JLabel();
        jLabel_btn_o9 = new javax.swing.JLabel();
        jLabel_btn1 = new javax.swing.JLabel();
        jLabel_btn2 = new javax.swing.JLabel();
        jLabel_btn3 = new javax.swing.JLabel();
        jLabel_btn4 = new javax.swing.JLabel();
        jLabel_btn5 = new javax.swing.JLabel();
        jLabel_btn6 = new javax.swing.JLabel();
        jLabel_btn7 = new javax.swing.JLabel();
        jLabel_btn8 = new javax.swing.JLabel();
        jLabel_btn9 = new javax.swing.JLabel();
        jLabel_reset = new javax.swing.JLabel();
        jLabel_exit = new javax.swing.JLabel();
        score_o = new javax.swing.JLabel();
        score_x = new javax.swing.JLabel();
        jLabel_bg_score_x = new javax.swing.JLabel();
        jLabel_bg_score_o = new javax.swing.JLabel();
        jLabel_score_o = new javax.swing.JLabel();
        jLabel_score_x = new javax.swing.JLabel();
        jLabel_lamp1 = new javax.swing.JLabel();
        jLabel_lamp = new javax.swing.JLabel();
        jLabel_background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Tic Tac Toe");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel_btn_x_win1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_x_win.png"))); // NOI18N
        jLabel_btn_x_win1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x_win1.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x_win1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x_win1MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x_win1, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 73, -1, -1));

        jLabel_btn_x_win2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_x_win.png"))); // NOI18N
        jLabel_btn_x_win2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x_win2.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x_win2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x_win2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x_win2, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 73, -1, -1));

        jLabel_btn_x_win3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_x_win.png"))); // NOI18N
        jLabel_btn_x_win3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x_win3.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x_win3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x_win3MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x_win3, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 73, -1, -1));

        jLabel_btn_x_win4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_x_win.png"))); // NOI18N
        jLabel_btn_x_win4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x_win4.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x_win4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x_win4MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x_win4, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 189, -1, -1));

        jLabel_btn_x_win5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_x_win.png"))); // NOI18N
        jLabel_btn_x_win5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x_win5.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x_win5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x_win5MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x_win5, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 189, -1, -1));

        jLabel_btn_x_win6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_x_win.png"))); // NOI18N
        jLabel_btn_x_win6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x_win6.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x_win6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x_win6MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x_win6, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 189, -1, -1));

        jLabel_btn_x_win7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_x_win.png"))); // NOI18N
        jLabel_btn_x_win7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x_win7.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x_win7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x_win7MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x_win7, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 304, -1, -1));

        jLabel_btn_x_win8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_x_win.png"))); // NOI18N
        jLabel_btn_x_win8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x_win8.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x_win8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x_win8MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x_win8, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 304, -1, -1));

        jLabel_btn_x_win9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_x_win.png"))); // NOI18N
        jLabel_btn_x_win9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x_win9.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x_win9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x_win9MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x_win9, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 304, -1, -1));

        jLabel_btn_o_win1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_o_win.png"))); // NOI18N
        jLabel_btn_o_win1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o_win1.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o_win1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o_win1MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o_win1, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 73, -1, -1));

        jLabel_btn_o_win2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_o_win.png"))); // NOI18N
        jLabel_btn_o_win2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o_win2.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o_win2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o_win2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o_win2, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 73, -1, -1));

        jLabel_btn_o_win3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_o_win.png"))); // NOI18N
        jLabel_btn_o_win3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o_win3.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o_win3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o_win3MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o_win3, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 73, -1, -1));

        jLabel_btn_o_win4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_o_win.png"))); // NOI18N
        jLabel_btn_o_win4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o_win4.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o_win4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o_win4MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o_win4, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 189, -1, -1));

        jLabel_btn_o_win5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_o_win.png"))); // NOI18N
        jLabel_btn_o_win5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o_win5.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o_win5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o_win5MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o_win5, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 189, -1, -1));

        jLabel_btn_o_win6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_o_win.png"))); // NOI18N
        jLabel_btn_o_win6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o_win6.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o_win6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o_win6MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o_win6, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 189, -1, -1));

        jLabel_btn_o_win7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_o_win.png"))); // NOI18N
        jLabel_btn_o_win7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o_win7.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o_win7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o_win7MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o_win7, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 304, -1, -1));

        jLabel_btn_o_win8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_o_win.png"))); // NOI18N
        jLabel_btn_o_win8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o_win8.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o_win8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o_win8MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o_win8, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 304, -1, -1));

        jLabel_btn_o_win9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_o_win.png"))); // NOI18N
        jLabel_btn_o_win9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o_win9.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o_win9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o_win9MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o_win9, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 304, -1, -1));

        jLabel_btn_x1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_x.png"))); // NOI18N
        jLabel_btn_x1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x1.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x1MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x1, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 73, -1, -1));

        jLabel_btn_x2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_x.png"))); // NOI18N
        jLabel_btn_x2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x2.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x2, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 73, -1, -1));

        jLabel_btn_x3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_x.png"))); // NOI18N
        jLabel_btn_x3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x3.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x3MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x3, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 73, -1, -1));

        jLabel_btn_x4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_x.png"))); // NOI18N
        jLabel_btn_x4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x4.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x4MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x4, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 189, -1, -1));

        jLabel_btn_x5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_x.png"))); // NOI18N
        jLabel_btn_x5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x5.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x5MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x5, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 189, -1, -1));

        jLabel_btn_x6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_x.png"))); // NOI18N
        jLabel_btn_x6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x6.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x6MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x6, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 189, -1, -1));

        jLabel_btn_x7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_x.png"))); // NOI18N
        jLabel_btn_x7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x7.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x7MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x7, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 304, -1, -1));

        jLabel_btn_x8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_x.png"))); // NOI18N
        jLabel_btn_x8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x8.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x8MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x8, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 304, -1, -1));

        jLabel_btn_x9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_x.png"))); // NOI18N
        jLabel_btn_x9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_x9.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_x9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_x9MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_x9, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 304, -1, -1));

        jLabel_btn_o1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_o.png"))); // NOI18N
        jLabel_btn_o1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o1.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o1MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o1, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 73, -1, -1));

        jLabel_btn_o2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_o.png"))); // NOI18N
        jLabel_btn_o2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o2.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o2, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 73, -1, -1));

        jLabel_btn_o3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_o.png"))); // NOI18N
        jLabel_btn_o3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o3.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o3MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o3, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 73, -1, -1));

        jLabel_btn_o4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_o.png"))); // NOI18N
        jLabel_btn_o4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o4.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o4MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o4, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 189, -1, -1));

        jLabel_btn_o5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_o.png"))); // NOI18N
        jLabel_btn_o5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o5.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o5MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o5, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 189, -1, -1));

        jLabel_btn_o6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_o.png"))); // NOI18N
        jLabel_btn_o6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o6.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o6MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o6, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 189, -1, -1));

        jLabel_btn_o7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_o.png"))); // NOI18N
        jLabel_btn_o7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o7.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o7MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o7, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 304, -1, -1));

        jLabel_btn_o8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_o.png"))); // NOI18N
        jLabel_btn_o8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o8.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o8MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o8, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 304, -1, -1));

        jLabel_btn_o9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/btn_o.png"))); // NOI18N
        jLabel_btn_o9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn_o9.setVerifyInputWhenFocusTarget(false);
        jLabel_btn_o9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn_o9MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn_o9, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 304, -1, -1));

        jLabel_btn1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/Btn.png"))); // NOI18N
        jLabel_btn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn1.setVerifyInputWhenFocusTarget(false);
        jLabel_btn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn1MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 73, -1, -1));

        jLabel_btn2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/Btn.png"))); // NOI18N
        jLabel_btn2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 73, -1, -1));

        jLabel_btn3.setIcon(new javax.swing.ImageIcon("E:\\Btn.png")); // NOI18N
        jLabel_btn3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn3MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn3, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 73, -1, -1));

        jLabel_btn4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/Btn.png"))); // NOI18N
        jLabel_btn4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn4MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn4, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 189, -1, -1));

        jLabel_btn5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/Btn.png"))); // NOI18N
        jLabel_btn5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn5MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn5, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 189, -1, -1));

        jLabel_btn6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/Btn.png"))); // NOI18N
        jLabel_btn6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn6MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn6, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 189, -1, -1));

        jLabel_btn7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/Btn.png"))); // NOI18N
        jLabel_btn7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn7MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn7, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 304, -1, -1));

        jLabel_btn8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/Btn.png"))); // NOI18N
        jLabel_btn8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn8MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn8, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 304, -1, -1));

        jLabel_btn9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/Btn.png"))); // NOI18N
        jLabel_btn9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_btn9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_btn9MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_btn9, new org.netbeans.lib.awtextra.AbsoluteConstraints(457, 304, -1, -1));

        jLabel_reset.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/b_reset.png"))); // NOI18N
        jLabel_reset.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_reset.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_resetMouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_reset, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, -1, -1));

        jLabel_exit.setIcon(new javax.swing.ImageIcon("E:\\b_exit.png")); // NOI18N
        jLabel_exit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel_exitMouseClicked(evt);
            }
        });
        jPanel1.add(jLabel_exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 350, -1, -1));

        score_o.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        score_o.setForeground(new java.awt.Color(255, 255, 51));
        score_o.setText("0");
        jPanel1.add(score_o, new org.netbeans.lib.awtextra.AbsoluteConstraints(709, 197, -1, -1));

        score_x.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        score_x.setForeground(new java.awt.Color(51, 255, 51));
        score_x.setText("0");
        jPanel1.add(score_x, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 197, -1, -1));

        jLabel_bg_score_x.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/bg_score.png"))); // NOI18N
        jPanel1.add(jLabel_bg_score_x, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 190, -1, -1));

        jLabel_bg_score_o.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/bg_score.png"))); // NOI18N
        jPanel1.add(jLabel_bg_score_o, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 190, -1, -1));

        jLabel_score_o.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/score_o.png"))); // NOI18N
        jPanel1.add(jLabel_score_o, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 90, -1, -1));

        jLabel_score_x.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/score_x.png"))); // NOI18N
        jPanel1.add(jLabel_score_x, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 90, -1, -1));

        jLabel_lamp1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/lam.png"))); // NOI18N
        jPanel1.add(jLabel_lamp1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-11, 46, -1, -1));

        jLabel_lamp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/lam.png"))); // NOI18N
        jPanel1.add(jLabel_lamp, new org.netbeans.lib.awtextra.AbsoluteConstraints(617, 47, -1, -1));

        jLabel_background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/Background.jpg"))); // NOI18N
        jPanel1.add(jLabel_background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 799, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel_btn_x_win9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x_win9MouseClicked
        // TODO add your handling code here:
        check(btn9);
    }//GEN-LAST:event_jLabel_btn_x_win9MouseClicked

    private void jLabel_btn_x_win8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x_win8MouseClicked
        // TODO add your handling code here:
        check(btn8);
    }//GEN-LAST:event_jLabel_btn_x_win8MouseClicked

    private void jLabel_btn_x_win7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x_win7MouseClicked
        // TODO add your handling code here:
        check(btn7);
    }//GEN-LAST:event_jLabel_btn_x_win7MouseClicked

    private void jLabel_btn_x_win6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x_win6MouseClicked
        // TODO add your handling code here:
        check(btn6);
    }//GEN-LAST:event_jLabel_btn_x_win6MouseClicked

    private void jLabel_btn_x_win5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x_win5MouseClicked
        // TODO add your handling code here:
        check(btn5);
    }//GEN-LAST:event_jLabel_btn_x_win5MouseClicked

    private void jLabel_btn_x_win4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x_win4MouseClicked
        // TODO add your handling code here:
        check(btn4);
    }//GEN-LAST:event_jLabel_btn_x_win4MouseClicked

    private void jLabel_btn_x_win3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x_win3MouseClicked
        // TODO add your handling code here:
        check(btn3);
    }//GEN-LAST:event_jLabel_btn_x_win3MouseClicked

    private void jLabel_btn_x_win2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x_win2MouseClicked
        // TODO add your handling code here:
        check(btn2);
    }//GEN-LAST:event_jLabel_btn_x_win2MouseClicked

    private void jLabel_btn_o_win9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o_win9MouseClicked
        // TODO add your handling code here:
        check(btn9);
    }//GEN-LAST:event_jLabel_btn_o_win9MouseClicked

    private void jLabel_btn_o_win8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o_win8MouseClicked
        // TODO add your handling code here:
        check(btn8);
    }//GEN-LAST:event_jLabel_btn_o_win8MouseClicked

    private void jLabel_btn_o_win7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o_win7MouseClicked
        // TODO add your handling code here:
        check(btn7);
    }//GEN-LAST:event_jLabel_btn_o_win7MouseClicked

    private void jLabel_btn_o_win6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o_win6MouseClicked
        // TODO add your handling code here:
        check(btn6);
    }//GEN-LAST:event_jLabel_btn_o_win6MouseClicked

    private void jLabel_btn_o_win5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o_win5MouseClicked
        // TODO add your handling code here:
        check(btn5);
    }//GEN-LAST:event_jLabel_btn_o_win5MouseClicked

    private void jLabel_btn_o_win4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o_win4MouseClicked
        // TODO add your handling code here:
        check(btn4);
    }//GEN-LAST:event_jLabel_btn_o_win4MouseClicked

    private void jLabel_btn_o_win3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o_win3MouseClicked
        // TODO add your handling code here:
        check(btn3);
    }//GEN-LAST:event_jLabel_btn_o_win3MouseClicked

    private void jLabel_btn9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn9MouseClicked
        // TODO add your handling code here:
        if(reset=="reset"){
            askreset();
        }else{
            if(btn9==""){
            btn9 = startGame;
            if(startGame.equalsIgnoreCase("X")){
                    jLabel_btn_x9.setVisible(true);
            }else{
                    jLabel_btn_o9.setVisible(true);
            }
            choose_a_player();
            winningGame();   
            }else{
                JOptionPane.showMessageDialog(this, "Is not valid. Try again or Click Reset...","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_jLabel_btn9MouseClicked

    private void jLabel_btn8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn8MouseClicked
        // TODO add your handling code here:
        if(reset=="reset"){
            askreset();
        }else{
            if(btn8==""){
            btn8 = startGame;
            if(startGame.equalsIgnoreCase("X")){
                    jLabel_btn_x8.setVisible(true);
            }else{
                    jLabel_btn_o8.setVisible(true);
            }
            choose_a_player();
            winningGame();   
            }else{
                JOptionPane.showMessageDialog(this, "Is not valid. Try again or Click Reset...","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_jLabel_btn8MouseClicked

    private void jLabel_btn7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn7MouseClicked
        // TODO add your handling code here:
        if(reset=="reset"){
            askreset();
        }else{
            if(btn7==""){
            btn7 = startGame;
            if(startGame.equalsIgnoreCase("X")){
                    jLabel_btn_x7.setVisible(true);
            }else{
                    jLabel_btn_o7.setVisible(true);
            }
            choose_a_player();
            winningGame();   
            }else{
                JOptionPane.showMessageDialog(this, "Is not valid. Try again or Click Reset...","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_jLabel_btn7MouseClicked

    private void jLabel_btn6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn6MouseClicked
        // TODO add your handling code here:
        
        if(reset=="reset"){
            askreset();
        }else{
            if(btn6==""){
            btn6 = startGame;
            if(startGame.equalsIgnoreCase("X")){
                    jLabel_btn_x6.setVisible(true);
            }else{
                    jLabel_btn_o6.setVisible(true);
            }
            choose_a_player();
            winningGame();   
            }else{
                JOptionPane.showMessageDialog(this, "Is not valid. Try again or Click Reset...","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_jLabel_btn6MouseClicked

    private void jLabel_btn5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn5MouseClicked
        // TODO add your handling code here:
        if(reset=="reset"){
            askreset();
        }else{
            if(btn5==""){
            btn5 = startGame;
            if(startGame.equalsIgnoreCase("X")){
                    jLabel_btn_x5.setVisible(true);
            }else{
                    jLabel_btn_o5.setVisible(true);
            }
            choose_a_player();
            winningGame();   
            }else{
                JOptionPane.showMessageDialog(this, "Is not valid. Try again or Click Reset...","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_jLabel_btn5MouseClicked

    private void jLabel_btn4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn4MouseClicked
        // TODO add your handling code here:
        if(reset=="reset"){
            askreset();
        }else{
            if(btn4==""){
            btn4 = startGame;
            if(startGame.equalsIgnoreCase("X")){
                    jLabel_btn_x4.setVisible(true);
            }else{
                    jLabel_btn_o4.setVisible(true);
            }
            choose_a_player();
            winningGame();   
            }else{
                JOptionPane.showMessageDialog(this, "Is not valid. Try again or Click Reset...","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_jLabel_btn4MouseClicked

    private void jLabel_btn3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn3MouseClicked
        // TODO add your handling code here:
        if(reset=="reset"){
            askreset();
        }else{
            if(btn3==""){
            btn3 = startGame;
            if(startGame.equalsIgnoreCase("X")){
                    jLabel_btn_x3.setVisible(true);
            }else{
                    jLabel_btn_o3.setVisible(true);
            }
            choose_a_player();
            winningGame();   
            }else{
                JOptionPane.showMessageDialog(this, "Is not valid. Try again or Click Reset...","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_jLabel_btn3MouseClicked

    private void jLabel_btn2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn2MouseClicked
        // TODO add your handling code here:        
        if(reset=="reset"){
            askreset();
        }else{
            if(btn2==""){
            btn2 = startGame;
            if(startGame.equalsIgnoreCase("X")){
                    jLabel_btn_x2.setVisible(true);
            }else{
                    jLabel_btn_o2.setVisible(true);
            }
            choose_a_player();
            winningGame();   
            }else{
                JOptionPane.showMessageDialog(this, "Is not valid. Try again or Click Reset...","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_jLabel_btn2MouseClicked

    private void jLabel_btn_o9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o9MouseClicked
        // TODO add your handling code here:
        check(btn9);
    }//GEN-LAST:event_jLabel_btn_o9MouseClicked

    private void jLabel_btn_o8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o8MouseClicked
        // TODO add your handling code here:
        check(btn8);
    }//GEN-LAST:event_jLabel_btn_o8MouseClicked

    private void jLabel_btn_o7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o7MouseClicked
        // TODO add your handling code here:
        check(btn7);
    }//GEN-LAST:event_jLabel_btn_o7MouseClicked

    private void jLabel_btn_o6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o6MouseClicked
        // TODO add your handling code here:
        check(btn6);
    }//GEN-LAST:event_jLabel_btn_o6MouseClicked

    private void jLabel_btn_o5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o5MouseClicked
        // TODO add your handling code here:
        check(btn5);
    }//GEN-LAST:event_jLabel_btn_o5MouseClicked

    private void jLabel_btn_o4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o4MouseClicked
        // TODO add your handling code here:
        check(btn4);
    }//GEN-LAST:event_jLabel_btn_o4MouseClicked

    private void jLabel_btn_o3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o3MouseClicked
        // TODO add your handling code here:
        check(btn3);
    }//GEN-LAST:event_jLabel_btn_o3MouseClicked

    private void jLabel_btn_o2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o2MouseClicked
        // TODO add your handling code here:
        check(btn2);
    }//GEN-LAST:event_jLabel_btn_o2MouseClicked

    private void jLabel_btn_x9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x9MouseClicked
        // TODO add your handling code here:
        check(btn9);
    }//GEN-LAST:event_jLabel_btn_x9MouseClicked

    private void jLabel_btn_x8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x8MouseClicked
        // TODO add your handling code here:
        check(btn8);
    }//GEN-LAST:event_jLabel_btn_x8MouseClicked

    private void jLabel_btn_x7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x7MouseClicked
        // TODO add your handling code here:
        check(btn7);
    }//GEN-LAST:event_jLabel_btn_x7MouseClicked

    private void jLabel_btn_x6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x6MouseClicked
        // TODO add your handling code here:
        check(btn6);
    }//GEN-LAST:event_jLabel_btn_x6MouseClicked

    private void jLabel_btn_x5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x5MouseClicked
        // TODO add your handling code here:
        check(btn5);
    }//GEN-LAST:event_jLabel_btn_x5MouseClicked

    private void jLabel_btn_x4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x4MouseClicked
        // TODO add your handling code here:
        check(btn4);
    }//GEN-LAST:event_jLabel_btn_x4MouseClicked

    private void jLabel_btn_x3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x3MouseClicked
        // TODO add your handling code here:
        check(btn3);
    }//GEN-LAST:event_jLabel_btn_x3MouseClicked

    private void jLabel_btn_x2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x2MouseClicked
        // TODO add your handling code here:
        check(btn2);
    }//GEN-LAST:event_jLabel_btn_x2MouseClicked

    private void jLabel_exitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_exitMouseClicked
        // TODO add your handling code here:
        frame = new JFrame("Exit");
        if(JOptionPane.showConfirmDialog(frame, "Confirm if you want to exit", "Tic Tac Toe",
            JOptionPane.YES_NO_OPTION )== JOptionPane.YES_NO_OPTION)
    {
        System.exit(0);
        }
    }//GEN-LAST:event_jLabel_exitMouseClicked

    private void jLabel_btn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn1MouseClicked
        // TODO add your handling code here:
        if(reset=="reset"){
            askreset();
        }else{
            if(btn1==""){
            btn1 = startGame;
            if(startGame.equalsIgnoreCase("X")){
                    jLabel_btn_x1.setVisible(true);
            }else{
                    jLabel_btn_o1.setVisible(true);
            }
            choose_a_player();
            winningGame();   
            }else{
                JOptionPane.showMessageDialog(this, "Is not valid. Try again or Click Reset...","Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_jLabel_btn1MouseClicked

    private void jLabel_btn_o1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o1MouseClicked
        // TODO add your handling code here:
        check(btn1);
    }//GEN-LAST:event_jLabel_btn_o1MouseClicked

    private void jLabel_btn_x1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x1MouseClicked
        // TODO add your handling code here:
        check(btn1);
    }//GEN-LAST:event_jLabel_btn_x1MouseClicked

    private void jLabel_btn_o_win1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o_win1MouseClicked
        // TODO add your handling code here:
        check(btn1);
    }//GEN-LAST:event_jLabel_btn_o_win1MouseClicked

    private void jLabel_btn_x_win1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_x_win1MouseClicked
        // TODO add your handling code here:
        check(btn1);
    }//GEN-LAST:event_jLabel_btn_x_win1MouseClicked

    private void jLabel_resetMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_resetMouseClicked
        // TODO add your handling code here:
            frame = new JFrame("Reset");
            if(JOptionPane.showConfirmDialog(frame, "Do You Want Reset The Game?", "Tic Tac Toe",JOptionPane.YES_NO_OPTION )== JOptionPane.YES_NO_OPTION)
            {
                start();
                reset="";
                btn1 = "";
                btn2 = "";
                btn3 = "";
                btn4 = "";
                btn5 = "";
                btn6 = "";
                btn7 = "";
                btn8 = "";
                btn9 = "";
            }
    }//GEN-LAST:event_jLabel_resetMouseClicked

    private void jLabel_btn_o_win2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel_btn_o_win2MouseClicked
        // TODO add your handling code here:
        check(btn2);
    }//GEN-LAST:event_jLabel_btn_o_win2MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Tic_Tac_Toe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Tic_Tac_Toe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Tic_Tac_Toe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Tic_Tac_Toe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tic_Tac_Toe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel_background;
    private javax.swing.JLabel jLabel_bg_score_o;
    private javax.swing.JLabel jLabel_bg_score_x;
    private javax.swing.JLabel jLabel_btn1;
    private javax.swing.JLabel jLabel_btn2;
    private javax.swing.JLabel jLabel_btn3;
    private javax.swing.JLabel jLabel_btn4;
    private javax.swing.JLabel jLabel_btn5;
    private javax.swing.JLabel jLabel_btn6;
    private javax.swing.JLabel jLabel_btn7;
    private javax.swing.JLabel jLabel_btn8;
    private javax.swing.JLabel jLabel_btn9;
    private javax.swing.JLabel jLabel_btn_o1;
    private javax.swing.JLabel jLabel_btn_o2;
    private javax.swing.JLabel jLabel_btn_o3;
    private javax.swing.JLabel jLabel_btn_o4;
    private javax.swing.JLabel jLabel_btn_o5;
    private javax.swing.JLabel jLabel_btn_o6;
    private javax.swing.JLabel jLabel_btn_o7;
    private javax.swing.JLabel jLabel_btn_o8;
    private javax.swing.JLabel jLabel_btn_o9;
    private javax.swing.JLabel jLabel_btn_o_win1;
    private javax.swing.JLabel jLabel_btn_o_win2;
    private javax.swing.JLabel jLabel_btn_o_win3;
    private javax.swing.JLabel jLabel_btn_o_win4;
    private javax.swing.JLabel jLabel_btn_o_win5;
    private javax.swing.JLabel jLabel_btn_o_win6;
    private javax.swing.JLabel jLabel_btn_o_win7;
    private javax.swing.JLabel jLabel_btn_o_win8;
    private javax.swing.JLabel jLabel_btn_o_win9;
    private javax.swing.JLabel jLabel_btn_x1;
    private javax.swing.JLabel jLabel_btn_x2;
    private javax.swing.JLabel jLabel_btn_x3;
    private javax.swing.JLabel jLabel_btn_x4;
    private javax.swing.JLabel jLabel_btn_x5;
    private javax.swing.JLabel jLabel_btn_x6;
    private javax.swing.JLabel jLabel_btn_x7;
    private javax.swing.JLabel jLabel_btn_x8;
    private javax.swing.JLabel jLabel_btn_x9;
    private javax.swing.JLabel jLabel_btn_x_win1;
    private javax.swing.JLabel jLabel_btn_x_win2;
    private javax.swing.JLabel jLabel_btn_x_win3;
    private javax.swing.JLabel jLabel_btn_x_win4;
    private javax.swing.JLabel jLabel_btn_x_win5;
    private javax.swing.JLabel jLabel_btn_x_win6;
    private javax.swing.JLabel jLabel_btn_x_win7;
    private javax.swing.JLabel jLabel_btn_x_win8;
    private javax.swing.JLabel jLabel_btn_x_win9;
    private javax.swing.JLabel jLabel_exit;
    private javax.swing.JLabel jLabel_lamp;
    private javax.swing.JLabel jLabel_lamp1;
    private javax.swing.JLabel jLabel_reset;
    private javax.swing.JLabel jLabel_score_o;
    private javax.swing.JLabel jLabel_score_x;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel score_o;
    private javax.swing.JLabel score_x;
    // End of variables declaration//GEN-END:variables
}
